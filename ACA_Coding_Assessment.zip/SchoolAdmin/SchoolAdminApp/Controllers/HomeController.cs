﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.IO;
using System.Linq;
using System.Threading.Tasks;

using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Http.Features;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

using SchoolAdmin.Server.ApplicationServices;
using SchoolAdmin.Server.DomainSerices;



using SchoolAdminApp.Models;
using SchoolAdmin.Server.DataServices;
namespace SchoolAdminApp.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly IApplicationService _appService;

        public HomeController(ILogger<HomeController> logger, IApplicationService appService)
        {
            _logger = logger;
            _appService = appService;
        }

        public IActionResult Index()
        {
            return View();
        }

        public IActionResult Privacy()
        {
            return View();
        }

        [HttpPost]
        public async Task<IActionResult> UploadFileAsync(IFormFile inboundFile)
        {



            if (inboundFile.Length > 0)
            {
                var filePath = Path.GetTempFileName();

                using (var stream = System.IO.File.Create(filePath))
                {
                    await inboundFile.CopyToAsync(stream);
                    //service here to handle input
                    StudentUploadFile file = new StudentUploadFile();
                    if (_appService.ParseInboundStudentFile(stream, inboundFile.FileName))
                    {
                        ViewBag.Message = string.Format("File Upload Complete for file:{0}", inboundFile.FileName);
                        return View("ClassUpload");

                    }
                }
            }
            return View();

        }
        
        public IActionResult CreateFile()
        {
            var result = _appService.CreateReportCardFile();
            ViewBag.FileCreated = result;
            return View();
        }

        
        public IActionResult ClassUpload()
        {
            
            return View();
        }

        public IActionResult ReportCard()
        {
           
            ReportCardViewModel model = new ReportCardViewModel() { StudentRecords = _appService.ListByClass("*") };
            
            return View(model);
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
    }
}
