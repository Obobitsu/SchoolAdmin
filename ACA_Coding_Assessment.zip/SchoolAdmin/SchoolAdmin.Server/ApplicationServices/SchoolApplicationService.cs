﻿using SchoolAdmin.Server.DataModel;
using SchoolAdmin.Server.DataServices;
using SchoolAdmin.Server.DomainSerices;

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.IO;
using System.Linq;
using System.Reflection.Metadata.Ecma335;
using System.Text;

namespace SchoolAdmin.Server.ApplicationServices
{
    public class SchoolApplicationService : IApplicationService
    {
        
        IFileParser _fileParser;
        IReadModelRepository _readModelRepository;
        IWriteModelRepository _writeModelRepository;
        IReportGenerator _reportGenerator;
       
        public SchoolApplicationService(IReadModelRepository readModelRepository,IWriteModelRepository writeModelRepository, IFileParser parser, IReportGenerator reportGenerator)
        {
            _readModelRepository = readModelRepository;
            _writeModelRepository = writeModelRepository;
            _fileParser = parser;
            _reportGenerator = reportGenerator;
        }

        public string CreateReportCardFile()
        {
            ReportCardReportModel model = new ReportCardReportModel() { StudentRecords = this.ListByClass("*") };
                        
            return _reportGenerator.CreateOutPutReport(model);
        }

        

        public bool ImportMany(List<StudentRecord> recordstoImport)
        {

            try
            {
                foreach (var student in recordstoImport)
                {
                    _writeModelRepository.Create<StudentRecord>(student);
                }
                return true;
            }
            catch (Exception ex)
            {
                throw ex;
                
            }


        }

        public bool ImportSingle(StudentRecord recordtoImport)
        {
            if (_writeModelRepository.Create<StudentRecord>(recordtoImport) > 0) return true;

            return false;
        }

       
        public List<StudentRecord> ListByClass(string className)
        {
            return (List<StudentRecord>)_readModelRepository.SearchByClass(className);
            
        }

        public bool ParseInboundStudentFile(Stream stream, string fileName)
        {
            try
            {
                List<StudentRecord> parsedRecords = new List<StudentRecord>();
                StudentUploadFile uploadFile = new StudentUploadFile(_fileParser);
                string className = fileName.Substring(0, fileName.IndexOf("."));   
                foreach (var record in uploadFile.Parse(stream, className))
                {
                    parsedRecords.Add(record);

                }
                return ImportMany(parsedRecords); ;
            }
            catch (Exception ex)
            {

                throw ex;
            }

                
        }
    }
}
