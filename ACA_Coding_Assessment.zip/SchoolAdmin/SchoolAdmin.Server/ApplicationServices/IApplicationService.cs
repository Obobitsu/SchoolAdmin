﻿using SchoolAdmin.Server.DataModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SchoolAdmin.Server.ApplicationServices
{
    public interface IApplicationService
    {
        bool ImportMany(List<StudentRecord> recordstoImport);
        bool ImportSingle(StudentRecord recordtoImport);

        List<StudentRecord> ListByClass(string className);

        string CreateReportCardFile();

        bool ParseInboundStudentFile(Stream file, string fileName);

    }
}
