﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace SchoolAdmin.Server.DataModel
{
    public class ReportCardReportModel
    {

        public virtual List<StudentRecord> StudentRecords { get; set; }

        public virtual IEnumerable<string> ClassNames()
        {

            var result = (from item in StudentRecords
                          where item.ClassName != null
                          select item.ClassName).Distinct();

            return result;
        }

        public virtual List<StudentRecord> GetStudentsByClass(string className)
        {

            var result = (from item in StudentRecords
                          where item.ClassName == className
                          select item).ToList();

            return result;

        }

        public virtual int? GetAverageByClass(string className)
        {

            var result = (from item in StudentRecords
                          where item.ClassName == className
                          select item.Grade);

            return result.Sum();

        }
    }
}
