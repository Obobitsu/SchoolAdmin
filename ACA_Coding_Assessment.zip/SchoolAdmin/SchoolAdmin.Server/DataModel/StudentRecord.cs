﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Runtime.Serialization;
using System.Text;

namespace SchoolAdmin.Server.DataModel
{
    [DataContract]
    public class StudentRecord
    {
        [DataMember]
        public virtual int Id { get; set; }

        [DataMember]
        [Required]
        public virtual string StudentName { get; set; }
        
        [DataMember]
        public virtual int? Grade { get; set; }
        
        [DataMember]
        public virtual string ClassName { get; set;}
    }
}
