﻿using SchoolAdmin.Server.DataModel;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;

namespace SchoolAdmin.Server.DomainSerices
{
    public class ClassReportGenerator : IReportGenerator
    {
        public string CreateOutPutReport(ReportCardReportModel model)
        {
            var filePath = Path.Combine(Path.GetTempPath(), $"ACASchoolReportCard{DateTime.Now.Year}-{DateTime.Now.Month}-{DateTime.Now.Day}-{DateTime.Now.Hour}-{DateTime.Now.Minute}-{DateTime.Now.Second}.txt");

            Dictionary<string, int> classWithAverage = new Dictionary<string, int>();


            foreach (var item in model.ClassNames())
            {
                var average = model.StudentRecords.Where(c => c.ClassName == item).Select(p => p.Grade).Sum() / model.StudentRecords.Where(c => c.ClassName == item && c.Grade > 0).Select(p => p.Grade).Count();
                classWithAverage.Add(item, (int)average);


            }


            var topClass = GetTopClass(classWithAverage);
            using (StreamWriter writer = new StreamWriter(filePath))
            {
                writer.WriteLine("------------------Class Report Card------------------");
                writer.WriteLine($"Report Date:{DateTime.Now}");
                writer.WriteLine("");
                writer.WriteLine("");
                writer.WriteLine($"Top Class:{topClass.Keys.First()} with average:{topClass.Values.First()}");

                writer.WriteLine("");
                writer.WriteLine($"Average of all Classes({classWithAverage.Count}):{classWithAverage.Average(p => p.Value)}");
                writer.WriteLine("Class listing");
                writer.WriteLine("");

                foreach (var item in classWithAverage.OrderBy(p => p.Value))
                {

                    writer.WriteLine($"Class Name:{item.Key} Student(s) used in Average Count:{model.StudentRecords.Where(p => p.ClassName == item.Key && p.Grade > 0).Count()}.Total Students in class:{model.StudentRecords.Where(p => p.ClassName == item.Key).Count()}");
                    writer.WriteLine("");
                    List<StudentRecord> omittedStudents = model.StudentRecords.Where(p => p.ClassName == item.Key && p.Grade == 0).ToList();
                    if (omittedStudents.Count > 0)
                    {
                        writer.WriteLine("  Students Not included in Average");

                        foreach (var student in omittedStudents)
                        {
                            writer.WriteLine("      " + student.StudentName);
                        }
                    }
                }


            }
            return filePath;

        }

        private Dictionary<string, int> GetTopClass(Dictionary<string, int> classWithAverage)
        {
            Dictionary<string, int> result = new Dictionary<string, int>();
            string className = "";
            int classAvg = 0;
            foreach (var item in classWithAverage)
            {
                if (string.IsNullOrWhiteSpace(className))
                {
                    className = item.Key;
                    classAvg = item.Value;
                }
                else
                {
                    if (item.Value > classAvg)
                    {
                        className = item.Key;
                        classAvg = item.Value;

                    }
                }

            }
            result.Add(className, classAvg);

            return result;
        }
    }
}
