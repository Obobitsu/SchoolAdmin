﻿using SchoolAdmin.Server.DataModel;

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SchoolAdmin.Server.DomainSerices
{
    public class CSVFileParser : IFileParser
    {
        public List<StudentRecord> Parse(Stream stream, string fileName)
        {
            //FileName will be class Name in BD
            try
            {

                Dictionary<string, double> importItems = new Dictionary<string, double>();
                List<StudentRecord> studentList = new List<StudentRecord>();
                stream.Position = 0;
                using (StreamReader reader = new StreamReader(stream, System.Text.Encoding.UTF8))
                {
                    int rowcount = 0;
                    while (!reader.EndOfStream)
                    {

                        var text = reader.ReadLine();
                        //deals with the header
                        if (rowcount == 0)
                        {
                            rowcount++;
                            continue;
                        }

                        //build a new object, service.AddNew(string)
                        string[] data = text.Split(",");
                        double grade = 0.0;
                        double.TryParse(data[1], out grade);
                        StudentRecord newStudent = new StudentRecord()
                        {
                            StudentName = data[0],
                            Grade = (int?)Math.Round(grade, MidpointRounding.ToZero),
                            ClassName = fileName
                        };
                        studentList.Add(newStudent);
                        rowcount++;
                    }
                    return studentList;
                }
            }
            catch (Exception ex)
            {

                throw ex;

            }

            

        }

    }
}
