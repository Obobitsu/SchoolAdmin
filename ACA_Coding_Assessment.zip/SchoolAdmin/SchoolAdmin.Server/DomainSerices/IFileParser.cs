﻿using SchoolAdmin.Server.DataModel;

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SchoolAdmin.Server.DomainSerices
{
    public interface IFileParser
    {
        List<StudentRecord> Parse(Stream stream, string fileName);
    }
}
