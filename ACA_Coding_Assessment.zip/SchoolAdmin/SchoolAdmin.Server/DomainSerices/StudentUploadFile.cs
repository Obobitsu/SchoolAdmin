﻿using SchoolAdmin.Server.DataModel;

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;

namespace SchoolAdmin.Server.DomainSerices
{
    public class StudentUploadFile
    {
        public StudentUploadFile()
        {
        }
        public StudentUploadFile(IFileParser parser)
        {
            _parser = parser;
           
        }

        public List<StudentRecord> studentRecords { get; set; }
        private IFileParser _parser;
         
       
            

        public List<StudentRecord> Parse(Stream stream, string fileName)
        {
            studentRecords= _parser.Parse(stream, fileName);
            return studentRecords;

        }
    }
}
