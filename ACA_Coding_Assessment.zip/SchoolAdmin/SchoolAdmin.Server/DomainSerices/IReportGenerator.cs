﻿using SchoolAdmin.Server.DataModel;
using System;
using System.Collections.Generic;
using System.Text;

namespace SchoolAdmin.Server.DomainSerices
{
    public interface IReportGenerator
    {

        string CreateOutPutReport(ReportCardReportModel model);
    }
}
