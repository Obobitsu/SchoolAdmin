﻿
using SchoolAdmin.Server.DataModel;

using System.Collections.Generic;


namespace SchoolAdmin.Server.DataServices
{
    //methods for searching returning objects
    public interface IReadModelRepository : IRepository
    {
               
       

        T Find<T>(int id) where T : class;

        IEnumerable<StudentRecord> SearchByClass(string className);
        

    }
}
