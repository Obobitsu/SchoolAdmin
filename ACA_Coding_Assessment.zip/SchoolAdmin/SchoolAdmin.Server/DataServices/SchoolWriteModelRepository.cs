﻿

namespace SchoolAdmin.Server.DataServices
{


    public class SchoolWriteModelRepository : RepositoryBase, IWriteModelRepository
    {
       
        public SchoolWriteModelRepository()
        {
            base.Initialize();

        }
        
        public int Create<T>(T objtoAdd) where T : class
        {
            
            using (var session = cfg.BuildSessionFactory().OpenSession())
            { 
                if (session != null)
                {
                    using (var tx = session.BeginTransaction())
                    {

                        //save object
                        var retval = session.Save((T)objtoAdd);

                        tx.Commit();

                        return (int)retval;
                    }
               }
            }
            return 0;
            
            
        }
        

        public int Delete<T>(int Id) where T : class
        {

            using (var session = cfg.BuildSessionFactory().OpenSession())
            {
                if (session != null)
                {
                    using (var tx = session.BeginTransaction())
                    {
                        //Delete object if exists
                        var obj = session.Get<T>(Id);
                        if (obj != null) session.Delete(obj);

                        tx.Commit();
                        return Id;
                    }
                }
                return 0;
            }
        }

        
        public bool Update<T>(T objtoUpdate) where T : class
        {
           
            using (var session = cfg.BuildSessionFactory().OpenSession())
            {
                if (session != null)
                {
                    using (var tx = session.BeginTransaction())
                    {
                                                   
                        session.Update(objtoUpdate);

                        tx.Commit();
                        return true;
                    }
                }
                return false;
            }
        }
        
        
    }
}
