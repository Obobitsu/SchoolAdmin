﻿using NHibernate.Dialect;
using NHibernate.Driver;
using System.Configuration;
using System.Reflection;

namespace SchoolAdmin.Server.DataServices
{
   public class RepositoryBase : IRepository
    {
       
        protected NHibernate.Cfg.Configuration cfg = new NHibernate.Cfg.Configuration();
        //Need to change
        private string connectionString = @"Server=DESKTOP-NS9K1IL\SQLEXPRESS;Database=SchoolAdmin;Integrated Security=True;";

        public void Initialize()
        {
            
            cfg.DataBaseIntegration(x =>
            {
                x.ConnectionString = connectionString;
                x.Driver<SqlClientDriver>();
                x.Dialect<MsSql2012Dialect>();
                x.LogSqlInConsole = true;

            });
            //location of models
            cfg.AddAssembly(Assembly.GetExecutingAssembly());

            cfg.AddXmlFile("SchoolAdmin.hbm.xml");
        }
    }
}
