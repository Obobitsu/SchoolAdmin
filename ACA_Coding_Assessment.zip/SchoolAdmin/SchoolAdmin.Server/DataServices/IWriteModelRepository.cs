﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace SchoolAdmin.Server.DataServices
{
    //Update Methods only
    public interface IWriteModelRepository : IRepository
    {
        //return Id of Added Item
        int Create<T>(T objtoAdd) where T : class;

        //return Id of removed item
        int Delete<T>(int Id) where T : class;

        //return success or not
        bool Update<T>(T objtoUpdate) where T : class;

    }
}
