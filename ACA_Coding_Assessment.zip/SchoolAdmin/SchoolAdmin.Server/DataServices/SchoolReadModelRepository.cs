﻿using SchoolAdmin.Server.DataModel;

using System.Collections.Generic;
using System.Linq;
using System.Reflection.Metadata.Ecma335;

namespace SchoolAdmin.Server.DataServices
{
    public class SchoolReadModelRepository : RepositoryBase, IReadModelRepository
    {

        public SchoolReadModelRepository()
        {
            base.Initialize();

        }
                              
        

        public T Find<T>(int id) where T : class
        {
            using (var session = cfg.BuildSessionFactory().OpenSession())
            {
                if (session != null)
                {
                    using (var tx = session.BeginTransaction())
                    {
                        //save object
                        var retval = session.Get<T>(id);


                        return retval;
                    }
                }
            }
            return null;
        }

        public IEnumerable<StudentRecord> SearchByClass(string className) 
        {
            List<StudentRecord> studentList = new List<StudentRecord>();
            using (var session = cfg.BuildSessionFactory().OpenSession())
            {
                if (session != null)
                {
                    using (var tx = session.BeginTransaction())
                    {

                        if (className == "*")
                        {
                            studentList = session.Query<StudentRecord>().Where(p => p.ClassName != null).OrderBy(r => r.ClassName).ThenBy(n=>n.StudentName).ToList();
                        }
                        else
                        {
                            studentList = session.Query<StudentRecord>().Where(p => p.ClassName.Contains(className)).OrderBy(r => r.ClassName).ThenBy(n => n.StudentName).ToList();

                        }
                    }
                }
            }
            return studentList;
        }
    }
}
