Connection String needs to point to your server. 
It Uses NHibernate for Data Access
Edit RepositoryBase for:
 
private string connectionString = @"Server=DESKTOP-NS9K1IL\SQLEXPRESS;Database=SchoolAdmin;Integrated Security=True;";

Run the Application, 
Choose: Import new Data files. Data files have been included
Menu Choose:Report Card
